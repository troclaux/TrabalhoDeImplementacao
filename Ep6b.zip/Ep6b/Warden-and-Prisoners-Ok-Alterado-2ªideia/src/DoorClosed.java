public class DoorClosed {
    public synchronized void myWait() throws InterruptedException {
        this.wait();
    }
    public synchronized void myNotifyAll() {
        this.notifyAll();
    }
}
